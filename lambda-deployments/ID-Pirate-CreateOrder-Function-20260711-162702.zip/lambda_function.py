# lambda_function.py — Create Order
# Pricing uses shared/order_pricing.py only — no payment_gateway dependency.

import json
import boto3
import uuid
import datetime
import decimal
import os
import sys
from boto3.dynamodb.conditions import Key

_LAMBDA_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _LAMBDA_ROOT not in sys.path:
    sys.path.insert(0, _LAMBDA_ROOT)

from shared.order_pricing import (
    calc_order_usd_total,
    shipping_is_delivery,
    resolve_pricing_mode,
    calc_reseller_portal_prices,
    RESELLER_PORTAL_SOURCE,
)

dynamodb = boto3.resource('dynamodb')


def price_for_dynamo(price: dict) -> dict:
    """DynamoDB rejects Python float — store money fields as Decimal."""
    out = {}
    for key, value in price.items():
        if isinstance(value, dict):
            out[key] = price_for_dynamo(value)
        elif isinstance(value, float):
            out[key] = decimal.Decimal(str(value))
        elif isinstance(value, int) and not isinstance(value, bool):
            out[key] = value
        else:
            out[key] = value
    return out
table = dynamodb.Table('idPirate_orders')
discounts_table = dynamodb.Table('idPirate_discounts')
users_table = dynamodb.Table('idPirate_users')


def _normalize_client_ip(raw):
    if not raw or not isinstance(raw, str):
        return None
    ip = raw.strip()[:45]
    if not ip or ip.lower() == 'unknown':
        return None
    return ip


def lambda_handler(event, context):
    print("Received event: " + json.dumps(event, indent=2))

    try:
        order_data = json.loads(event['body'])

        if 'userId' not in order_data or not order_data['userId']:
            raise ValueError("Order must contain a 'userId'.")
        if 'ids' not in order_data or not order_data['ids']:
            raise ValueError("Order must contain at least one ID document in 'ids' array.")

        order_id = str(uuid.uuid4())

        shipping_address = None
        incoming_shipping_data = order_data.get('shipping')
        if isinstance(incoming_shipping_data, str):
            shipping_address = incoming_shipping_data
        elif isinstance(incoming_shipping_data, dict) and 'address' in incoming_shipping_data:
            shipping_address = incoming_shipping_data['address']

        discount_code = order_data.get('discountCode')
        ship_delivery = shipping_is_delivery(shipping_address)
        source = order_data.get('source')
        customer_price_snapshot = None
        wholesale_cost_snapshot = None

        if source == RESELLER_PORTAL_SOURCE:
            reseller_id = order_data.get('resellerId') or order_data.get('userId')
            client_cp = (order_data.get('customerPrice') or {}).get('total')
            portal_prices = calc_reseller_portal_prices(
                order_data['ids'],
                ship_delivery,
                users_table,
                reseller_id,
                client_cp,
            )
            price = portal_prices['price']
            customer_price_snapshot = portal_prices['customerPrice']
            wholesale_cost_snapshot = portal_prices['wholesaleCost']
        else:
            pricing_mode = resolve_pricing_mode(order_data, users_table)

            # Allowed-usernames enforcement: look up the user's username so we
            # can pass it to the discount validator. If the code is restricted
            # and this user isn't on the list, server-side pricing will raise
            # ValueError (caught below) and the order will be rejected.
            order_username = (order_data.get('username') or '').strip().lower()
            if not order_username:
                # Best-effort: resolve username from users_table by userId
                try:
                    _qr = users_table.query(
                        KeyConditionExpression=Key('userId').eq(order_data['userId'])
                    )
                    _items = _qr.get('Items', [])
                    if _items:
                        order_username = (_items[0].get('username') or '').strip().lower()
                except Exception as _ue:
                    print(f'[create_order] username lookup failed: {_ue}')

            # Pre-flight: if a discount code is restricted to usernames and
            # this user isn't allowed, fail fast (don't even compute price).
            if discount_code:
                _d = discounts_table.get_item(Key={'code': discount_code.strip().upper()}).get('Item')
                if _d:
                    _allowed = _d.get('allowedUsernames')
                    if _allowed:
                        _allowed_set = _allowed if isinstance(_allowed, (set, frozenset)) else set(_allowed)
                        if not order_username or order_username not in _allowed_set:
                            raise ValueError('This discount code is not available for your account.')

            try:
                price = calc_order_usd_total(
                    order_data['ids'],
                    ship_delivery,
                    discount_code,
                    discounts_table if discount_code else None,
                    pricing_mode,
                )
            except Exception as pricing_err:
                print(f'[create_order] server pricing fallback: {pricing_err}')
                client_price = order_data.get('price') or {}
                price = {
                    'subtotal': float(client_price.get('subtotal', 0)),
                    'total': float(client_price.get('total', 0)),
                }

        now = datetime.datetime.utcnow().isoformat() + 'Z'
        item_to_save = {
            'orderId': order_id,
            'userId': order_data['userId'],
            'status': 'pending',
            'shipping': shipping_address,
            'paymentMethod': order_data.get('paymentMethod'),
            'paymentStatus': 'Unpaid',
            'notes': order_data.get('notes'),
            'price': price_for_dynamo(price),
            'ids': order_data['ids'],
            'source': order_data.get('source'),
            'resellerId': order_data.get('resellerId'),
            'batchStatus': 'unbatched',
            'createdAt': now,
            'updatedAt': now,
        }
        if customer_price_snapshot:
            item_to_save['customerPrice'] = price_for_dynamo(customer_price_snapshot)
        if wholesale_cost_snapshot:
            item_to_save['wholesaleCost'] = price_for_dynamo(wholesale_cost_snapshot)
        if discount_code:
            item_to_save['discountCode'] = discount_code.strip().upper()
        # Persist scope + per-line breakdown if present (line_item codes)
        if isinstance(price, dict):
            if price.get('discountScope'):
                item_to_save['discountScope'] = price['discountScope']
            if price.get('discountAppliedTo'):
                item_to_save['discountAppliedTo'] = price_for_dynamo(
                    {'_': price['discountAppliedTo']}
                )['_']
            # AFFILIATE PROGRAM: persist commission + owner for payout tracking
            if price.get('commissionEarned') is not None:
                item_to_save['commissionEarned'] = decimal.Decimal(str(price['commissionEarned']))
                item_to_save['affiliateOwner'] = price.get('affiliateOwner')
                item_to_save['affiliatePaid'] = False

        client_ip = _normalize_client_ip(order_data.get('clientIp'))
        if client_ip:
            item_to_save['clientIp'] = client_ip

        table.put_item(Item=item_to_save)

        # Increment discount usedCount atomically (Gap 2 fix — previously never
        # incremented, so maxUses was effectively unenforceable past validation).
        if discount_code:
            try:
                discounts_table.update_item(
                    Key={'code': discount_code.strip().upper()},
                    UpdateExpression='ADD usedCount :inc SET updatedAt = :now',
                    ExpressionAttributeValues={':inc': 1, ':now': now},
                )
            except Exception as inc_err:
                # Don't fail the order over a counter increment — log and continue.
                print(f'[create_order] usedCount increment failed: {inc_err}')

        return {
            'statusCode': 201,
            'headers': {
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST,OPTIONS',
            },
            'body': json.dumps({
                'message': 'Order created successfully!',
                'orderId': order_id,
                'price': price,
            }),
        }

    except ValueError as e:
        return {
            'statusCode': 400,
            'headers': {
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST,OPTIONS',
            },
            'body': json.dumps({'error': str(e)}),
        }
    except Exception as e:
        print(f"Error: {e}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST,OPTIONS',
            },
            'body': json.dumps({'error': f'Internal server error occurred: {str(e)}'}),
        }
