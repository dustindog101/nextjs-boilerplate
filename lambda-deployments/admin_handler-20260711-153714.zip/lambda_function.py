# admin_handler.py — ID Pirate Admin Lambda
# Handles all admin-only operations via requestType dispatch.
# Every request must carry a valid admin JWT.
#
# DynamoDB Tables used:
#   idPirate_users     (userId PK, username SK, UsernameIndex GSI)
#   idPirate_orders    (orderId PK, UserIdIndex GSI on userId)
#   idPirate_discounts (code PK)
#   idPirate_batches   (batchId PK)

import json
import os
import boto3
import decimal
import jwt
import datetime
from boto3.dynamodb.conditions import Key, Attr

from payment_admin import is_payment_admin_request, dispatch_payment_admin

# --- Configuration ---
JWT_SECRET    = os.environ.get('JWT_SECRET', 'your_super_secret_jwt_key_for_dev_only')
JWT_ALGORITHM = "HS256"

USERS_TABLE_NAME     = 'idPirate_users'
ORDERS_TABLE_NAME    = 'idPirate_orders'
DISCOUNTS_TABLE_NAME = 'idPirate_discounts'
BATCHES_TABLE_NAME   = 'idPirate_batches'
SETTINGS_TABLE_NAME  = 'idPirate_settings'

USER_ID_ORDER_GSI = 'UserIdIndex'  # GSI on idPirate_orders: userId

# --- AWS Resources ---
dynamodb       = boto3.resource('dynamodb')
users_table    = dynamodb.Table(USERS_TABLE_NAME)
orders_table   = dynamodb.Table(ORDERS_TABLE_NAME)
discounts_table = dynamodb.Table(DISCOUNTS_TABLE_NAME)
batches_table  = dynamodb.Table(BATCHES_TABLE_NAME)
_settings_table = None


def _get_settings_table():
    global _settings_table
    if _settings_table is None:
        _settings_table = dynamodb.Table(SETTINGS_TABLE_NAME)
    return _settings_table

# ── Helpers ────────────────────────────────────────────────────────────────────

class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            return int(o) if o % 1 == 0 else float(o)
        if isinstance(o, (set, frozenset)):
            # DynamoDB returns String Sets as frozenset. JSON can't serialize
            # sets directly — convert to a sorted list for stable output.
            return sorted(o)
        return super().default(o)

def now_iso():
    return datetime.datetime.utcnow().isoformat() + 'Z'

def _parse_iso(s):
    """Parse an ISO 8601 string (with or without trailing 'Z') into an
    aware UTC datetime. Raises ValueError on bad input."""
    if not s or not isinstance(s, str):
        raise ValueError("date must be a non-empty string")
    dt = datetime.datetime.fromisoformat(s.replace('Z', '+00:00'))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=datetime.timezone.utc)
    return dt

def verify_admin_jwt(auth_header):
    """Decode JWT and assert role == admin. Raises on failure."""
    if not auth_header:
        raise PermissionError("Authorization header is missing.")
    parts = auth_header.split()
    if len(parts) != 2 or parts[0].lower() != "bearer":
        raise PermissionError("Authorization header must be 'Bearer <token>'.")
    token = parts[1]
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        if payload.get('role') != 'admin':
            raise PermissionError("Access denied: Administrator privileges required.")
        return payload
    except jwt.ExpiredSignatureError:
        raise PermissionError("Token has expired.")
    except jwt.InvalidTokenError:
        raise PermissionError("Invalid token.")

def verify_reseller_jwt(auth_header):
    """Accept admin OR reseller tokens. Returns the decoded payload."""
    if not auth_header:
        raise PermissionError("Authorization header is missing.")
    parts = auth_header.split()
    if len(parts) != 2 or parts[0].lower() != "bearer":
        raise PermissionError("Authorization header must be 'Bearer <token>'.")
    token = parts[1]
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        role = payload.get('role')
        is_reseller = payload.get('isReseller', False)
        if role != 'admin' and not is_reseller:
            raise PermissionError("Access denied: Reseller or admin privileges required.")
        return payload
    except jwt.ExpiredSignatureError:
        raise PermissionError("Token has expired.")
    except jwt.InvalidTokenError:
        raise PermissionError("Invalid token.")

def ok(data, encoder=True):
    body = json.dumps(data, cls=DecimalEncoder) if encoder else json.dumps(data)
    return {'statusCode': 200, 'headers': HEADERS, 'body': body}

def err(msg, status=400):
    return {'statusCode': status, 'headers': HEADERS, 'body': json.dumps({'error': msg})}

def get_authorization_header(event):
    """Bearer token from API Gateway or Lambda Function URL (header keys vary by casing)."""
    headers = event.get('headers') or {}
    if isinstance(headers, dict):
        for key in headers:
            if key.lower() == 'authorization':
                return headers[key]
    mvh = event.get('multiValueHeaders') or {}
    if isinstance(mvh, dict):
        for key in mvh:
            if key.lower() == 'authorization':
                vals = mvh[key]
                if vals:
                    return vals[0]
    return None

HEADERS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'POST,OPTIONS',
    'Content-Type': 'application/json',
}

# ── Main Handler ───────────────────────────────────────────────────────────────

def lambda_handler(event, context):
    # Handle CORS preflight
    method = event.get('requestContext', {}).get('http', {}).get('method', '')
    if method == 'OPTIONS':
        return {'statusCode': 204, 'headers': HEADERS, 'body': ''}

    try:
        auth_header = get_authorization_header(event)

        # Parse body + requestType first so we can route auth accordingly
        body = event.get('body')
        if not body:
            return err("Request body is empty.")
        rb = json.loads(body)
        rt = rb.get('requestType')
        if not rt:
            return err("Missing 'requestType'.")

        # Reseller-permitted endpoints use their own auth check (verify_reseller_jwt).
        # Everything else requires a full admin token.
        RESELLER_PERMITTED = {'reseller_update_order'}
        if rt not in RESELLER_PERMITTED:
            verify_admin_jwt(auth_header)

        # ── USER MANAGEMENT ────────────────────────────────────────────────────

        if rt == 'list_all_users':
            resp = users_table.scan()
            users = resp.get('Items', [])
            for u in users:
                u.pop('hashedPassword', None)
            return ok(users)

        elif rt == 'admin_update_user':
            user_id     = rb.get('userId')
            username    = rb.get('username')   # Required — part of composite PK (sort key)
            update_data = rb.get('updateData', {})
            if not user_id or not username or not update_data:
                return err("Missing 'userId', 'username', or 'updateData'.")

            allowed = ['role', 'isReseller', 'discount', 'notes']
            set_parts, remove_parts = [], []
            vals, names = {}, {}
            for k, v in update_data.items():
                if k not in allowed:
                    continue
                if v is None:
                    # Explicit remove (e.g. clearing discount)
                    remove_parts.append(f"#{k}")
                    names[f"#{k}"] = k
                else:
                    set_parts.append(f"#{k} = :{k}")
                    vals[f":{k}"] = v
                    names[f"#{k}"] = k

            if not set_parts and not remove_parts:
                return err("No valid fields to update.")

            set_parts.append("#updatedAt = :updatedAt")
            vals[":updatedAt"] = now_iso()
            names["#updatedAt"] = "updatedAt"

            update_expr = "SET " + ", ".join(set_parts)
            if remove_parts:
                update_expr += " REMOVE " + ", ".join(remove_parts)

            users_table.update_item(
                Key={'userId': user_id, 'username': username},
                UpdateExpression=update_expr,
                ExpressionAttributeValues=vals,
                ExpressionAttributeNames=names,
            )
            return ok({'message': f'User {user_id} updated.'})

        elif rt == 'admin_delete_user':
            user_id = rb.get('userId')
            username = rb.get('username')  # needed for composite PK
            if not user_id or not username:
                return err("Requires 'userId' and 'username'.")
            users_table.delete_item(Key={'userId': user_id, 'username': username})
            return ok({'message': f'User {user_id} deleted.'})

        # ── ORDER MANAGEMENT ───────────────────────────────────────────────────

        elif rt == 'list_all_orders':
            # Scan all orders. For large datasets add pagination via ExclusiveStartKey.
            resp = orders_table.scan()
            orders = resp.get('Items', [])
            for o in orders:
                o['numberOfIds'] = len(o.get('ids', []))
            return ok(orders)

        elif rt == 'get_order':
            order_id = rb.get('orderId')
            if not order_id:
                return err("Missing 'orderId'.")
            resp = orders_table.get_item(Key={'orderId': order_id})
            item = resp.get('Item')
            if not item:
                return err(f"Order '{order_id}' not found.", 404)
            item['numberOfIds'] = len(item.get('ids', []))
            return ok(item)

        elif rt == 'admin_update_order':
            order_id    = rb.get('orderId')
            update_data = rb.get('updateData', {})
            if not order_id or not update_data:
                return err("Requires 'orderId' and 'updateData'.")

            allowed = [
                'status', 'paymentStatus', 'paymentMethod', 'notes', 'shipping',
                'trackingNumber', 'customerNotice', 'paymentExpiresAt', 'cryptoAsset', 'cryptoTxHash',
            ]
            parts, vals, names = [], {}, {}
            for k, v in update_data.items():
                if k in allowed:
                    parts.append(f"#{k} = :{k}")
                    vals[f":{k}"] = v
                    names[f"#{k}"] = k
            if not parts:
                return err("No valid fields to update.")

            parts.append("#updatedAt = :updatedAt")
            vals[":updatedAt"] = now_iso()
            names["#updatedAt"] = "updatedAt"

            orders_table.update_item(
                Key={'orderId': order_id},
                UpdateExpression="SET " + ", ".join(parts),
                ExpressionAttributeValues=vals,
                ExpressionAttributeNames=names,
            )
            return ok({'message': f'Order {order_id} updated.'})

        # ── RESELLER ORDER UPDATE ───────────────────────────────────────────────
        # Resellers can update status/paymentStatus on their own orders only.
        # Admins can use this endpoint too and skip the ownership check.

        elif rt == 'reseller_update_order':
            reseller_payload = verify_reseller_jwt(auth_header)

            order_id    = rb.get('orderId')
            update_data = rb.get('updateData', {})
            if not order_id or not update_data:
                return err("Requires 'orderId' and 'updateData'.")

            # Fetch order first to check ownership
            order_resp = orders_table.get_item(Key={'orderId': order_id})
            order = order_resp.get('Item')
            if not order:
                return err(f"Order '{order_id}' not found.", 404)

            # Admins bypass ownership check; resellers must own the order
            caller_user_id = reseller_payload.get('userId')
            if reseller_payload.get('role') != 'admin' and order.get('userId') != caller_user_id:
                return err("Access denied: This order does not belong to you.", 403)

            # Resellers may only touch status + paymentStatus
            reseller_allowed = ['status', 'paymentStatus']
            parts, vals, names = [], {}, {}
            for k, v in update_data.items():
                if k in reseller_allowed:
                    parts.append(f"#{k} = :{k}")
                    vals[f":{k}"] = v
                    names[f"#{k}"] = k
            if not parts:
                return err("No valid fields. Resellers may update: status, paymentStatus.")

            parts.append("#updatedAt = :updatedAt")
            vals[":updatedAt"] = now_iso()
            names["#updatedAt"] = "updatedAt"

            orders_table.update_item(
                Key={'orderId': order_id},
                UpdateExpression="SET " + ", ".join(parts),
                ExpressionAttributeValues=vals,
                ExpressionAttributeNames=names,
            )
            return ok({'message': f'Order {order_id} updated.'})

        # ── DISCOUNT MANAGEMENT ────────────────────────────────────────────────

        elif rt == 'list_discounts':
            resp = discounts_table.scan()
            return ok(resp.get('Items', []))

        elif rt == 'create_discount':
            code = rb.get('code', '').strip().upper()
            if not code:
                return err("Missing 'code'.")
            discount_type  = rb.get('discountType', 'percentage')  # 'percentage' | 'fixed'
            discount_value = rb.get('value', 0)
            expires_at     = rb.get('expiresAt')     # ISO string or None
            starts_at      = rb.get('startsAt')      # ISO string or None (NEW)
            max_uses       = rb.get('maxUses')       # int or None
            min_order      = rb.get('minOrder', 0)
            scope          = rb.get('scope', 'cart')  # 'cart' | 'line_item' (NEW)
            product_ids    = rb.get('productIds')     # list[str] or None (NEW)
            allowed_usernames = rb.get('allowedUsernames')  # list[str] or None (NEW)

            # Validate scope
            if scope not in ('cart', 'line_item'):
                return err("scope must be 'cart' or 'line_item'.")
            if scope == 'line_item':
                if not product_ids or not isinstance(product_ids, list) or len(product_ids) == 0:
                    return err("scope='line_item' requires at least one productId.")
                # De-duplicate + uppercase product IDs (catalog convention)
                product_ids = list({str(p).strip().upper() for p in product_ids if str(p).strip()})

            # Validate value
            try:
                discount_value = float(discount_value)
            except (TypeError, ValueError):
                return err("value must be a number.")
            if discount_value <= 0:
                return err("value must be greater than 0.")
            if discount_type == 'percentage' and discount_value > 100:
                return err("percentage value cannot exceed 100.")

            # Validate dates
            if starts_at and expires_at:
                try:
                    if _parse_iso(starts_at) >= _parse_iso(expires_at):
                        return err("startsAt must be before expiresAt.")
                except ValueError as ve:
                    return err(f"Invalid date: {ve}")

            item = {
                'code': code,
                'discountType': discount_type,
                'value': decimal.Decimal(str(discount_value)),
                'minOrder': decimal.Decimal(str(min_order)),
                'usedCount': 0,
                'isActive': True,
                'scope': scope,
                'createdAt': now_iso(),
            }
            if expires_at:
                item['expiresAt'] = expires_at
            if starts_at:
                item['startsAt'] = starts_at
            if max_uses is not None:
                item['maxUses'] = int(max_uses)
            if scope == 'line_item':
                # DynamoDB String Set — natural fit for membership lookups
                item['productIds'] = set(product_ids)
            if allowed_usernames:
                # Normalize: lowercase, trim, de-dup
                usernames = list({str(u).strip().lower() for u in allowed_usernames if str(u).strip()})
                if usernames:
                    item['allowedUsernames'] = set(usernames)

            # Prevent overwriting an existing code
            discounts_table.put_item(
                Item=item,
                ConditionExpression=Attr('code').not_exists()
            )
            return ok({'message': f'Discount code "{code}" created.'})

        elif rt == 'update_discount':
            code = rb.get('code', '').strip().upper()
            update_data = rb.get('updateData', {})
            if not code or not update_data:
                return err("Requires 'code' and 'updateData'.")

            # Extended allow-list with new fields
            allowed = [
                'discountType', 'value', 'minOrder', 'expiresAt', 'maxUses', 'isActive',
                'scope', 'productIds', 'startsAt', 'allowedUsernames',  # NEW
            ]
            set_parts, remove_parts = [], []
            vals, names = {}, {}
            for k, v in update_data.items():
                if k not in allowed:
                    continue

                if v is None:
                    # Explicit removal (e.g. clearing productIds / allowedUsernames)
                    remove_parts.append(f"#{k}")
                    names[f"#{k}"] = k
                    continue

                if k == 'scope':
                    if v not in ('cart', 'line_item'):
                        return err("scope must be 'cart' or 'line_item'.")
                    set_parts.append(f"#{k} = :{k}")
                    vals[f":{k}"] = v
                    names[f"#{k}"] = k
                elif k == 'productIds':
                    if not isinstance(v, list) or len(v) == 0:
                        return err("productIds must be a non-empty list.")
                    pid_set = {str(p).strip().upper() for p in v if str(p).strip()}
                    if not pid_set:
                        return err("productIds must contain at least one non-empty value.")
                    set_parts.append(f"#{k} = :{k}")
                    vals[f":{k}"] = pid_set  # DynamoDB String Set
                    names[f"#{k}"] = k
                elif k == 'allowedUsernames':
                    if not isinstance(v, list):
                        return err("allowedUsernames must be a list.")
                    un_set = {str(u).strip().lower() for u in v if str(u).strip()}
                    if not un_set:
                        # Empty list -> remove the attribute instead of storing empty set
                        remove_parts.append(f"#{k}")
                        names[f"#{k}"] = k
                        continue
                    set_parts.append(f"#{k} = :{k}")
                    vals[f":{k}"] = un_set
                    names[f"#{k}"] = k
                elif k in ('value', 'minOrder'):
                    set_parts.append(f"#{k} = :{k}")
                    vals[f":{k}"] = decimal.Decimal(str(v))
                    names[f"#{k}"] = k
                elif k == 'maxUses':
                    set_parts.append(f"#{k} = :{k}")
                    vals[f":{k}"] = int(v)
                    names[f"#{k}"] = k
                elif k == 'isActive':
                    set_parts.append(f"#{k} = :{k}")
                    vals[f":{k}"] = bool(v)
                    names[f"#{k}"] = k
                else:
                    # discountType, expiresAt, startsAt — strings
                    set_parts.append(f"#{k} = :{k}")
                    vals[f":{k}"] = v
                    names[f"#{k}"] = k

            if not set_parts and not remove_parts:
                return err("No valid fields.")

            set_parts.append("#updatedAt = :updatedAt")
            vals[":updatedAt"] = now_iso()
            names["#updatedAt"] = "updatedAt"

            update_expr = "SET " + ", ".join(set_parts)
            if remove_parts:
                update_expr += " REMOVE " + ", ".join(remove_parts)

            discounts_table.update_item(
                Key={'code': code},
                UpdateExpression=update_expr,
                ExpressionAttributeValues=vals,
                ExpressionAttributeNames=names,
            )
            return ok({'message': f'Discount "{code}" updated.'})

        elif rt == 'delete_discount':
            code = rb.get('code', '').strip().upper()
            if not code:
                return err("Missing 'code'.")
            discounts_table.delete_item(Key={'code': code})
            return ok({'message': f'Discount "{code}" deleted.'})

        # ── METRICS ────────────────────────────────────────────────────────────

        elif rt == 'get_metrics':
            # Scan-based metrics — acceptable at this scale.
            orders_resp = orders_table.scan(
                ProjectionExpression='orderId, #s, price, createdAt, userId, paymentStatus',
                ExpressionAttributeNames={'#s': 'status'}
            )
            all_orders = orders_resp.get('Items', [])

            users_resp  = users_table.scan(ProjectionExpression='userId, createdAt, isReseller')
            all_users   = users_resp.get('Items', [])

            total_revenue = sum(
                float(o.get('price', {}).get('total', 0))
                for o in all_orders
                if o.get('paymentStatus') == 'Paid'
            )
            status_counts = {}
            for o in all_orders:
                s = o.get('status', 'unknown')
                status_counts[s] = status_counts.get(s, 0) + 1

            reseller_count = sum(1 for u in all_users if u.get('isReseller'))

            return ok({
                'totalOrders':   len(all_orders),
                'totalUsers':    len(all_users),
                'totalRevenue':  round(total_revenue, 2),
                'resellerCount': reseller_count,
                'statusBreakdown': status_counts,
            })

        # ── REFERRALS / AFFILIATES ────────────────────────────────────────────

        elif rt == 'list_referrals':
            # Find all users who have a referredBy field set.
            resp = users_table.scan(
                FilterExpression=Attr('referredBy').exists(),
                ProjectionExpression='userId, username, referredBy, createdAt',
            )
            referred = resp.get('Items', [])

            # Group by referrer
            referral_map = {}
            for u in referred:
                referrer = u.get('referredBy', '')
                if referrer not in referral_map:
                    referral_map[referrer] = []
                referral_map[referrer].append({
                    'userId': u['userId'],
                    'username': u['username'],
                    'joinedAt': u.get('createdAt', ''),
                })

            result = [
                {'referrer': k, 'referredUsers': v, 'count': len(v)}
                for k, v in referral_map.items()
            ]
            result.sort(key=lambda x: x['count'], reverse=True)
            return ok(result)

        elif is_payment_admin_request(rt):
            try:
                data = dispatch_payment_admin(rt, rb, _get_settings_table(), orders_table)
                return ok(data)
            except ImportError as e:
                return err(f'Crypto payment module error: {e}', 503)
            except ValueError as e:
                msg = str(e)
                if 'not deployed' in msg.lower() or 'not enabled' in msg.lower():
                    return err(msg, 503)
                return err(msg, 400)

        else:
            return err(f"Unknown requestType: '{rt}'.")

    except PermissionError as e:
        return err(str(e), 403)
    except ValueError as e:
        return err(str(e), 400)
    except discounts_table.meta.client.exceptions.ConditionalCheckFailedException:
        return err("Discount code already exists.", 409)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return err('Internal server error.', 500)