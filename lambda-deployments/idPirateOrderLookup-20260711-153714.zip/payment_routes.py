"""
Optional crypto payment routes — lazy-loaded so LOOKUP works without payment_shared/
or payment DynamoDB tables. Core track/discount/order flows are unaffected.
"""

import os
import sys

_LAMBDA_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _LAMBDA_ROOT not in sys.path:
    sys.path.insert(0, _LAMBDA_ROOT)

_PAYMENT_HANDLERS = None
_PAYMENT_LOAD_FAILED = False

PAYMENT_REQUEST_TYPES = frozenset({
    'list_crypto_methods',
    'create_payment_intent',
    'get_payment_intent',
    'cancel_payment_intent',
})


def is_payment_request(request_type: str) -> bool:
    return request_type in PAYMENT_REQUEST_TYPES


def _load_handlers():
    global _PAYMENT_HANDLERS, _PAYMENT_LOAD_FAILED
    if _PAYMENT_LOAD_FAILED:
        return None
    if _PAYMENT_HANDLERS is not None:
        return _PAYMENT_HANDLERS
    try:
        from payment_shared import handlers as h
        _PAYMENT_HANDLERS = h
        return h
    except ImportError as e:
        print(f'[payment_routes] payment_shared not available: {e}')
        _PAYMENT_LOAD_FAILED = True
        return None


def dispatch_payment(request_type, body, user_id, settings_table, intents_table, orders_table, discounts_table, users_table=None):
    handlers = _load_handlers()
    if handlers is None:
        if request_type == 'list_crypto_methods':
            return {'methods': [], 'enabled': False}
        raise ValueError('Crypto payment gateway is not deployed on this environment.')

    if request_type == 'list_crypto_methods':
        return handlers.handle_list_crypto_methods(settings_table)
    if request_type == 'create_payment_intent':
        return handlers.handle_create_payment_intent(
            body, user_id, settings_table, intents_table, orders_table, discounts_table, users_table
        )
    if request_type == 'get_payment_intent':
        return handlers.handle_get_payment_intent(body, user_id, intents_table, orders_table)
    if request_type == 'cancel_payment_intent':
        return handlers.handle_cancel_payment_intent(body, user_id, intents_table, orders_table)
    raise ValueError(f"Unknown payment requestType: '{request_type}'")
