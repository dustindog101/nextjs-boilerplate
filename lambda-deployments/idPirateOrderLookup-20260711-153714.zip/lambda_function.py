# order_lookup.py — ID Pirate Order Lookup Lambda
# Handles public tracking and authenticated order fetching.
#
# Public  requestTypes : 'track', 'summary', 'validate_discount', 'validate_reseller', 'get_reseller_public_pricing', 'list_crypto_methods'
# Protected requestTypes: 'list_user_orders', 'get_order', 'create_payment_intent', 'get_payment_intent', 'cancel_payment_intent'
#
# Next.js POST /api/orders/track forwards the JSON body + Authorization (when present).

import json
import os
import boto3
import decimal
import jwt
import datetime
from boto3.dynamodb.conditions import Key

from payment_routes import is_payment_request, dispatch_payment

JWT_SECRET       = os.environ.get('JWT_SECRET', 'your_super_secret_jwt_key_for_dev_only')
JWT_ALGORITHM    = "HS256"
ORDERS_TABLE     = 'idPirate_orders'
DISCOUNTS_TABLE  = 'idPirate_discounts'
USERS_TABLE      = 'idPirate_users'
USER_ID_GSI      = 'UserIdIndex'
RESELLER_PORTAL_SOURCE = 'reseller_portal'

dynamodb       = boto3.resource('dynamodb')
orders_table   = dynamodb.Table(ORDERS_TABLE)
discounts_table = dynamodb.Table(DISCOUNTS_TABLE)
users_table    = dynamodb.Table(USERS_TABLE)

_payment_tables_cache = None


def _payment_tables():
    """Lazy DynamoDB refs for optional crypto gateway (avoids import-time coupling)."""
    global _payment_tables_cache
    if _payment_tables_cache is not None:
        return _payment_tables_cache
    import os
    import sys
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if root not in sys.path:
        sys.path.insert(0, root)
    from payment_shared.config import SETTINGS_TABLE, INTENTS_TABLE
    _payment_tables_cache = (
        dynamodb.Table(SETTINGS_TABLE),
        dynamodb.Table(INTENTS_TABLE),
    )
    return _payment_tables_cache

class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            return int(o) if o % 1 == 0 else float(o)
        if isinstance(o, (set, frozenset)):
            # DynamoDB returns String Sets as frozenset. JSON can't serialize
            # sets directly — convert to a sorted list for stable output.
            return sorted(o)
        return super().default(o)

def verify_jwt(auth_header):
    if not auth_header:
        raise ValueError("Authorization header is missing.")
    parts = auth_header.split()
    if len(parts) != 2 or parts[0].lower() != "bearer":
        raise ValueError("Invalid Authorization format.")
    try:
        return jwt.decode(parts[1], JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError):
        raise ValueError("Token is invalid or expired.")

def ok(data):
    return {'statusCode': 200, 'body': json.dumps(data, cls=DecimalEncoder)}

def err(msg, status=400):
    return {'statusCode': status, 'body': json.dumps({'error': msg})}

def _now_utc():
    """Aware UTC now — avoids deprecated datetime.utcnow()."""
    return datetime.datetime.now(datetime.timezone.utc)

def _parse_iso(s):
    """Parse an ISO 8601 string (with or without trailing 'Z') into an
    aware UTC datetime. Raises ValueError on bad input."""
    if not s or not isinstance(s, str):
        raise ValueError("date must be a non-empty string")
    dt = datetime.datetime.fromisoformat(s.replace('Z', '+00:00'))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=datetime.timezone.utc)
    return dt

def get_authorization_header(event):
    """Bearer token from API Gateway or Lambda Function URL (header keys vary by casing)."""
    headers = event.get('headers') or {}
    if isinstance(headers, dict):
        for key in headers:
            if key.lower() == 'authorization':
                return headers[key]
    mvh = event.get('multiValueHeaders') or {}
    if isinstance(mvh, dict):
        for key in mvh:
            if key.lower() == 'authorization':
                vals = mvh[key]
                if vals:
                    return vals[0]
    return None

def sanitize_public_track_order(item):
    """Public track/summary: no per-ID PII, no userId, no R2 keys."""
    ids = item.get('ids') or []
    out = {
        'orderId': item.get('orderId'),
        'createdAt': item.get('createdAt'),
        'status': item.get('status'),
        'shipping': item.get('shipping'),
        'paymentMethod': item.get('paymentMethod'),
        'paymentStatus': item.get('paymentStatus'),
        'price': item.get('price'),
        'numberOfIds': len(ids),
        'paymentIntentId': item.get('paymentIntentId'),
        'cryptoAsset': item.get('cryptoAsset'),
        'cryptoTxHash': item.get('cryptoTxHash'),
        'paymentExpiresAt': item.get('paymentExpiresAt'),
        'customerNotice': item.get('customerNotice'),
    }
    return out

def lambda_handler(event, context):
    try:
        body = event.get('body')
        if not body:
            return {'statusCode': 200, 'body': json.dumps({'message': 'Preflight OK'})}

        rb = json.loads(body)
        rt = rb.get('requestType')
        if not rt:
            return err("Missing 'requestType'.")

        # ── Public endpoints ────────────────────────────────────────────────

        if rt in ['track', 'summary']:
            order_id = rb.get('orderId')
            if not order_id:
                return err("Missing 'orderId'.")
            resp = orders_table.get_item(Key={'orderId': order_id})
            item = resp.get('Item')
            if not item:
                return err(f"Order '{order_id}' not found.", 404)
            return ok(sanitize_public_track_order(item))

        elif rt == 'validate_discount':
            code       = rb.get('code', '').strip().upper()
            order_total = float(rb.get('orderTotal', 0))
            items      = rb.get('items')          # NEW: optional line items
            username   = (rb.get('username') or '').strip().lower()  # NEW
            if not code:
                return err("Missing discount code.")

            resp = discounts_table.get_item(Key={'code': code})
            d = resp.get('Item')
            if not d:
                return err("Invalid discount code.", 404)
            if not d.get('isActive', True):
                return err("Discount code is no longer active.")

            # Check startsAt (NEW — previously never checked)
            starts_at = d.get('startsAt')
            if starts_at:
                try:
                    start_dt = _parse_iso(starts_at)
                except ValueError:
                    return err("Discount code has an invalid startsAt.")
                if _now_utc() < start_dt:
                    return err("Discount code is not yet active.")

            # Check expiry
            expires_at = d.get('expiresAt')
            if expires_at:
                try:
                    exp_dt = _parse_iso(expires_at)
                except ValueError:
                    return err("Discount code has an invalid expiresAt.")
                if _now_utc() > exp_dt:
                    return err("Discount code has expired.")

            # Check usage limit
            max_uses = d.get('maxUses')
            if max_uses is not None and int(d.get('usedCount', 0)) >= int(max_uses):
                return err("Discount code has reached its usage limit.")

            # Check allowed usernames (NEW — previously never checked)
            allowed_usernames = d.get('allowedUsernames')
            if allowed_usernames:
                # DynamoDB returns a frozenset for String Set
                if not isinstance(allowed_usernames, (set, frozenset)):
                    allowed_usernames = set(allowed_usernames)
                if not username:
                    return err("This discount code is restricted to specific users — log in to use it.", 403)
                if username not in allowed_usernames:
                    return err("This discount code is not available for your account.", 403)

            # Check minimum order (against whole-cart subtotal — decision 5A)
            min_order = float(d.get('minOrder', 0))
            if order_total < min_order:
                return err(f"Minimum order of ${min_order:.2f} required for this code.")

            scope          = d.get('scope', 'cart')  # default for old codes
            discount_type  = d.get('discountType', 'percentage')
            discount_value = float(d.get('value', 0))

            if scope == 'line_item':
                # Require items[] for per-line-item math
                if not items or not isinstance(items, list) or len(items) == 0:
                    return err("This discount applies to specific products — provide cart items to validate.")

                product_ids = d.get('productIds') or set()
                if not isinstance(product_ids, (set, frozenset)):
                    product_ids = set(product_ids)
                if not product_ids:
                    return err("Discount code misconfigured: no productIds set for line_item scope.")

                applied_to = []
                discount_amount = 0.0
                for it in items:
                    pid = (it.get('productId') or '').strip().upper()
                    if not pid or pid not in product_ids:
                        continue
                    try:
                        qty = int(it.get('quantity', 1))
                    except (TypeError, ValueError):
                        qty = 1
                    if qty <= 0:
                        continue
                    try:
                        unit_price = float(it.get('unitPrice', 0))
                    except (TypeError, ValueError):
                        unit_price = 0.0
                    if unit_price <= 0:
                        continue

                    if discount_type == 'percentage':
                        per_unit = round(unit_price * (discount_value / 100), 2)
                    else:  # fixed — per unit (decision 4A)
                        per_unit = min(discount_value, unit_price)
                    per_unit = max(per_unit, 0.0)
                    line_discount = round(per_unit * qty, 2)
                    discount_amount += line_discount
                    applied_to.append({
                        'productId': pid,
                        'quantity': qty,
                        'unitPrice': round(unit_price, 2),
                        'perUnitDiscount': per_unit,
                        'lineDiscount': line_discount,
                    })

                discount_amount = round(min(discount_amount, order_total), 2)
                # Convert product_ids set to list for JSON response
                product_ids_list = sorted(product_ids)

                return ok({
                    'code': code,
                    'discountType': discount_type,
                    'value': discount_value,
                    'scope': scope,
                    'productIds': product_ids_list,
                    'discountAmount': discount_amount,
                    'newTotal': round(order_total - discount_amount, 2),
                    'appliedTo': applied_to,
                })

            # Default: whole-cart scope (existing behavior)
            if discount_type == 'percentage':
                discount_amount = round(order_total * (discount_value / 100), 2)
            else:  # fixed
                discount_amount = min(discount_value, order_total)

            return ok({
                'code': code,
                'discountType': discount_type,
                'value': discount_value,
                'scope': 'cart',
                'discountAmount': discount_amount,
                'newTotal': round(order_total - discount_amount, 2),
            })

        elif rt == 'validate_reseller':
            # Public: used by Next.js /api/uploads/reseller-session (no JWT).
            # resellerId is the portal subdomain slug (username), not always userId UUID.
            reseller_id = (rb.get('resellerId') or '').strip().lower()
            if not reseller_id:
                return err("Missing 'resellerId'.")
            u = None
            if len(reseller_id) == 36 and reseller_id.count('-') == 4:
                ur = users_table.get_item(Key={'userId': reseller_id})
                u = ur.get('Item')
            if not u:
                qr = users_table.query(
                    IndexName='UsernameIndex',
                    KeyConditionExpression=Key('username').eq(reseller_id),
                )
                items = qr.get('Items', [])
                u = items[0] if items else None
            if u and u.get('isReseller') is True:
                return ok({'valid': True, 'isReseller': True})
            return ok({'valid': False})

        elif rt == 'get_reseller_public_pricing':
            import sys
            root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            if root not in sys.path:
                sys.path.insert(0, root)
            from shared.order_pricing import (
                get_reseller_retail_per_id,
                HANDLING_FEE,
                SHIPPING_FEE,
            )

            reseller_id = (rb.get('resellerId') or '').strip().lower()
            if not reseller_id:
                return err("Missing 'resellerId'.")
            retail = get_reseller_retail_per_id(users_table, reseller_id)
            if retail is None:
                return err('Reseller not found.', 404)
            return ok({
                'defaultPerId': retail,
                'handlingFee': HANDLING_FEE,
                'shippingFee': SHIPPING_FEE,
            })

        # ── Optional crypto payment gateway (isolated in payment_routes.py) ──

        elif is_payment_request(rt):
            if rt == 'list_crypto_methods':
                try:
                    settings_table, intents_table = _payment_tables()
                except ImportError:
                    return ok({'methods': [], 'enabled': False})
                data = dispatch_payment(
                    rt, rb, None, settings_table, intents_table, orders_table, discounts_table, users_table
                )
                return ok(data)

            order_id = rb.get('orderId')
            pay_token = rb.get('payToken')
            user_id = None

            if pay_token:
                if not order_id:
                    return err("Missing 'orderId' for pay token auth.")
                try:
                    from payment_shared.pay_token import verify_pay_token
                except ImportError:
                    return err('Crypto payment gateway is not deployed.', 503)
                if not verify_pay_token(pay_token, order_id):
                    return err('Invalid or expired pay token.', 403)
                order_resp = orders_table.get_item(Key={'orderId': order_id})
                order = order_resp.get('Item')
                if not order:
                    return err(f"Order '{order_id}' not found.", 404)
                if order.get('paymentStatus') == 'Paid':
                    return err('Order is already paid.')
                user_id = order.get('userId')
                if not user_id:
                    return err('Order has no owner.', 400)
            else:
                auth_header = get_authorization_header(event)
                payload = verify_jwt(auth_header)
                user_id = payload.get('userId')

            try:
                settings_table, intents_table = _payment_tables()
            except ImportError:
                return err('Crypto payment gateway is not deployed.', 503)
            data = dispatch_payment(
                rt, rb, user_id, settings_table, intents_table, orders_table, discounts_table, users_table
            )
            return ok(data)

        # ── Protected endpoints ─────────────────────────────────────────────

        elif rt == 'list_user_orders':
            auth_header = get_authorization_header(event)
            payload = verify_jwt(auth_header)
            user_id = payload.get('userId')

            resp = orders_table.query(
                IndexName=USER_ID_GSI,
                KeyConditionExpression=Key('userId').eq(user_id)
            )
            orders = [
                o for o in resp.get('Items', [])
                if o.get('source') != RESELLER_PORTAL_SOURCE
            ]
            for o in orders:
                o['numberOfIds'] = len(o.get('ids', []))
            return ok({'orders': orders})

        elif rt == 'get_order':
            # Auth required — user can only fetch their own order
            auth_header = get_authorization_header(event)
            payload = verify_jwt(auth_header)
            user_id  = payload.get('userId')
            order_id = rb.get('orderId')
            if not order_id:
                return err("Missing 'orderId'.")

            resp = orders_table.get_item(Key={'orderId': order_id})
            item = resp.get('Item')
            if not item:
                return err(f"Order '{order_id}' not found.", 404)

            # Security: non-admins can only see their own orders
            if item.get('userId') != user_id and payload.get('role') != 'admin':
                return err("Access denied.", 403)

            item['numberOfIds'] = len(item.get('ids', []))
            return ok(item)

        else:
            return err(f"Unknown requestType: '{rt}'.")

    except PermissionError as e:
        return err(str(e), 403)
    except ValueError as e:
        return err(str(e), 400)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return err('Internal server error.', 500)