"""
Admin payment activity — list invoices and summary counts for the Payments hub.

Uses GSI StatusExpiresIndex (status + expiresAt) instead of table scans to stay
within DynamoDB free-tier patterns at low/medium volume. Trade-off: listing "all"
statuses requires up to 5 GSI queries merged in memory (acceptable while intent
volume is small; add a CreatedAt GSI if this becomes hot).
"""

import datetime

from boto3.dynamodb.conditions import Key

from .settings import sanitize_intent_for_client, list_enabled_asset_ids

ALL_STATUSES = ('pending', 'detected', 'confirmed', 'expired', 'cancelled')
ACTIVE_STATUSES = ('pending', 'detected')
EPOCH_ISO = '1970-01-01T00:00:00Z'
DEFAULT_RAIL = 'crypto'


def _intent_rail(intent):
    return intent.get('rail') or DEFAULT_RAIL


def _query_intents_by_status(intents_table, status, limit=200):
    """Fetch intents for one status via StatusExpiresIndex."""
    items = []
    kwargs = {
        'IndexName': 'StatusExpiresIndex',
        'KeyConditionExpression': Key('status').eq(status) & Key('expiresAt').gte(EPOCH_ISO),
        'Limit': min(int(limit), 200),
    }
    while True:
        resp = intents_table.query(**kwargs)
        items.extend(resp.get('Items', []))
        if len(items) >= limit:
            break
        lek = resp.get('LastEvaluatedKey')
        if not lek:
            break
        kwargs['ExclusiveStartKey'] = lek
    return items[:limit]


def _count_by_status(intents_table, status):
    total = 0
    kwargs = {
        'IndexName': 'StatusExpiresIndex',
        'KeyConditionExpression': Key('status').eq(status) & Key('expiresAt').gte(EPOCH_ISO),
        'Select': 'COUNT',
    }
    while True:
        resp = intents_table.query(**kwargs)
        total += resp.get('Count', 0)
        lek = resp.get('LastEvaluatedKey')
        if not lek:
            break
        kwargs['ExclusiveStartKey'] = lek
    return total


def _confirmed_last_7_days(intents_table):
    cutoff = (
        datetime.datetime.utcnow() - datetime.timedelta(days=7)
    ).replace(microsecond=0).isoformat() + 'Z'
    count = 0
    for item in _query_intents_by_status(intents_table, 'confirmed', limit=500):
        confirmed_at = item.get('confirmedAt') or item.get('createdAt') or ''
        if confirmed_at >= cutoff:
            count += 1
    return count


def handle_get_payment_activity_summary(body, intents_table, settings_table):
    settings = settings_table.get_item(Key={'pk': 'site'}).get('Item') or {}
    gateways = settings.get('paymentGateways') or {}
    enabled_assets = list_enabled_asset_ids({'paymentGateways': gateways})

    pending = _count_by_status(intents_table, 'pending')
    detected = _count_by_status(intents_table, 'detected')
    return {
        'active': pending + detected,
        'pending': pending,
        'detected': detected,
        'confirmed': _count_by_status(intents_table, 'confirmed'),
        'confirmedLast7Days': _confirmed_last_7_days(intents_table),
        'expired': _count_by_status(intents_table, 'expired'),
        'cancelled': _count_by_status(intents_table, 'cancelled'),
        'enabledCryptoAssets': len(enabled_assets),
    }


def _statuses_for_filter(status_filter):
    if not status_filter or status_filter == 'all':
        return ALL_STATUSES
    if status_filter == 'active':
        return ACTIVE_STATUSES
    if status_filter in ALL_STATUSES:
        return (status_filter,)
    raise ValueError(f"Invalid status filter: '{status_filter}'.")


def _batch_get_orders(orders_table, order_ids):
    if not order_ids:
        return {}
    keys = [{'orderId': oid} for oid in order_ids]
    out = {}
    for i in range(0, len(keys), 100):
        chunk = keys[i : i + 100]
        table_name = orders_table.table_name
        resp = orders_table.meta.client.batch_get_item(
            RequestItems={
                table_name: {
                    'Keys': chunk,
                    'ProjectionExpression': (
                        'orderId, userId, #src, resellerId, paymentStatus, '
                        'paymentMethod, #st, price, createdAt'
                    ),
                    'ExpressionAttributeNames': {'#src': 'source', '#st': 'status'},
                }
            }
        )
        for item in resp.get('Responses', {}).get(table_name, []):
            out[item['orderId']] = item
        unprocessed = resp.get('UnprocessedKeys', {}).get(table_name, {})
        if unprocessed.get('Keys'):
            retry = orders_table.meta.client.batch_get_item(
                RequestItems={table_name: unprocessed}
            )
            for item in retry.get('Responses', {}).get(table_name, []):
                out[item['orderId']] = item
    return out


def _slim_order(order):
    if not order:
        return None
    price = order.get('price') or {}
    total = price.get('total')
    if total is not None:
        try:
            total = float(total)
        except (TypeError, ValueError):
            pass
    return {
        'orderId': order.get('orderId'),
        'userId': order.get('userId'),
        'source': order.get('source'),
        'resellerId': order.get('resellerId'),
        'paymentStatus': order.get('paymentStatus'),
        'paymentMethod': order.get('paymentMethod'),
        'status': order.get('status'),
        'orderTotal': total,
        'createdAt': order.get('createdAt'),
    }


def _matches_search(intent, order, search):
    if not search:
        return True
    q = search.strip().lower()
    if not q:
        return True
    if q in (intent.get('orderId') or '').lower():
        return True
    if q in (intent.get('intentId') or '').lower():
        return True
    if q in (intent.get('txHash') or '').lower():
        return True
    if order and q in (order.get('userId') or '').lower():
        return True
    return False


def handle_list_payment_intents(body, intents_table, orders_table):
    status_filter = body.get('status', 'all')
    asset_filter = (body.get('asset') or '').strip() or None
    search = body.get('search') or ''
    limit = min(max(int(body.get('limit', 50)), 1), 100)

    statuses = _statuses_for_filter(status_filter)
    per_status_limit = limit if len(statuses) == 1 else min(limit * 2, 200)

    raw_items = []
    for st in statuses:
        raw_items.extend(_query_intents_by_status(intents_table, st, limit=per_status_limit))

    if asset_filter:
        raw_items = [i for i in raw_items if i.get('asset') == asset_filter]

    raw_items.sort(key=lambda x: x.get('createdAt') or '', reverse=True)

    order_ids = list({i['orderId'] for i in raw_items if i.get('orderId')})
    orders_map = _batch_get_orders(orders_table, order_ids)

    enriched = []
    for item in raw_items:
        order = orders_map.get(item.get('orderId'))
        if not _matches_search(item, order, search):
            continue
        row = sanitize_intent_for_client(item)
        row['rail'] = _intent_rail(item)
        row['order'] = _slim_order(order)
        enriched.append(row)
        if len(enriched) >= limit:
            break

    return {'intents': enriched, 'count': len(enriched)}
