"""Optional admin payment settings — lazy-loaded."""

import os
import sys

import boto3

_LAMBDA_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _LAMBDA_ROOT not in sys.path:
    sys.path.insert(0, _LAMBDA_ROOT)

_PAYMENT_ADMIN = None
_LOAD_FAILED = False

PAYMENT_ADMIN_TYPES = frozenset({
    'get_payment_settings',
    'update_payment_settings',
    'set_order_payment_expiry',
    'get_order_payment_intent',
    'admin_create_payment_intent',
    'admin_cancel_payment_intent',
    'get_payment_activity_summary',
    'list_payment_intents',
})


def is_payment_admin_request(request_type: str) -> bool:
    return request_type in PAYMENT_ADMIN_TYPES


def _modules():
    global _PAYMENT_ADMIN, _LOAD_FAILED
    if _LOAD_FAILED:
        return None
    if _PAYMENT_ADMIN is not None:
        return _PAYMENT_ADMIN
    try:
        from payment_shared.config import SETTINGS_PK, INTENTS_TABLE, DISCOUNTS_TABLE
        from payment_shared.settings import get_settings, default_settings, now_iso
        from payment_shared.gateway import safe_get_settings, is_crypto_payments_enabled
        from payment_shared.validation import validate_gateway_settings
        from payment_shared import handlers as payment_handlers
        from payment_shared import admin_activity

        _PAYMENT_ADMIN = {
            'SETTINGS_PK': SETTINGS_PK,
            'INTENTS_TABLE': INTENTS_TABLE,
            'DISCOUNTS_TABLE': DISCOUNTS_TABLE,
            'get_settings': get_settings,
            'default_settings': default_settings,
            'now_iso': now_iso,
            'safe_get_settings': safe_get_settings,
            'is_crypto_payments_enabled': is_crypto_payments_enabled,
            'validate_gateway_settings': validate_gateway_settings,
            'handlers': payment_handlers,
            'admin_activity': admin_activity,
        }
        return _PAYMENT_ADMIN
    except ImportError as e:
        print(f'[payment_admin] payment_shared not available: {e}')
        _LOAD_FAILED = True
        return None


def _table_refs(m):
    dynamodb = boto3.resource('dynamodb')
    intents_table = dynamodb.Table(m['INTENTS_TABLE'])
    discounts_table = dynamodb.Table(m['DISCOUNTS_TABLE'])
    return intents_table, discounts_table


def dispatch_payment_admin(request_type, rb, settings_table, orders_table):
    m = _modules()
    if m is None:
        raise ValueError('Crypto payment gateway is not deployed on this environment.')

    if request_type == 'get_payment_settings':
        return m['safe_get_settings'](settings_table)

    if request_type == 'update_payment_settings':
        if not m['is_crypto_payments_enabled']():
            raise ValueError('Crypto payments are disabled (CRYPTO_PAYMENTS_ENABLED=false).')
        gateways = rb.get('paymentGateways')
        ttl_hours = rb.get('paymentIntentTtlHours')
        if gateways is None:
            raise ValueError("Missing 'paymentGateways'.")
        errors = m['validate_gateway_settings'](gateways)
        if errors:
            raise ValueError('; '.join(errors))
        if ttl_hours is not None:
            ttl_hours = int(ttl_hours)
            if ttl_hours < 1 or ttl_hours > 168:
                raise ValueError('paymentIntentTtlHours must be between 1 and 168.')
        item = {
            'pk': m['SETTINGS_PK'],
            'paymentGateways': gateways,
            'paymentIntentTtlHours': int(ttl_hours) if ttl_hours is not None else 48,
            'updatedAt': m['now_iso'](),
        }
        settings_table.put_item(Item=item)
        return {'message': 'Payment settings updated.', 'settings': item}

    if request_type == 'set_order_payment_expiry':
        order_id = rb.get('orderId')
        payment_expires_at = rb.get('paymentExpiresAt')
        if not order_id:
            raise ValueError("Missing 'orderId'.")
        if payment_expires_at is None:
            orders_table.update_item(
                Key={'orderId': order_id},
                UpdateExpression='REMOVE paymentExpiresAt SET updatedAt = :u',
                ExpressionAttributeValues={':u': m['now_iso']()},
            )
        else:
            orders_table.update_item(
                Key={'orderId': order_id},
                UpdateExpression='SET paymentExpiresAt = :e, updatedAt = :u',
                ExpressionAttributeValues={
                    ':e': payment_expires_at,
                    ':u': m['now_iso'](),
                },
            )
        return {'message': f'Payment expiry updated for order {order_id}.'}

    intents_table, discounts_table = _table_refs(m)
    h = m['handlers']

    if request_type == 'get_order_payment_intent':
        return h.handle_admin_get_payment_intent(rb, intents_table, orders_table)

    if request_type == 'admin_create_payment_intent':
        intent = h.handle_admin_create_payment_intent(
            rb, settings_table, intents_table, orders_table, discounts_table
        )
        return {'intent': intent}

    if request_type == 'admin_cancel_payment_intent':
        return h.handle_admin_cancel_payment_intent(rb, intents_table, orders_table)

    aa = m['admin_activity']
    if request_type == 'get_payment_activity_summary':
        return aa.handle_get_payment_activity_summary(rb, intents_table, settings_table)

    if request_type == 'list_payment_intents':
        return aa.handle_list_payment_intents(rb, intents_table, orders_table)

    raise ValueError(f"Unknown payment admin requestType: '{request_type}'")
