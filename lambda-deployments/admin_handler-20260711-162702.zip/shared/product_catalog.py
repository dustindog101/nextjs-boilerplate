"""
Product catalog — keep in sync with lib/productCatalog.ts.
Update both files together when adding products or changing list prices.
"""

DEFAULT_STANDARD_PRICE = 95
PREMIUM_PRICE_ADD = 25
CDL_PRICE_ADD = 35
UK_BASE_PRICE = 105
DEFAULT_PRODUCT_ID = 'PA:STANDARD'

REGION_STANDARD_PRICES = {
    'Pennsylvania': 90,
    'New Jersey': 100,
    'Maine': 85,
    'Washington': 85,
    'Oregon': 85,
    'South Carolina': 85,
    'Missouri': 85,
    'Illinois': 90,
    'Connecticut': 90,
    'Arizona': 90,
    'Florida': 100,
    'Texas': 100,
    'California': 100,
    'New York': 100,
}

US_REGIONS = [
    ('AL', 'Alabama'), ('AK', 'Alaska'), ('AZ', 'Arizona'), ('AR', 'Arkansas'),
    ('CA', 'California'), ('CO', 'Colorado'), ('CT', 'Connecticut'), ('DE', 'Delaware'),
    ('DC', 'District of Columbia'), ('FL', 'Florida'), ('GA', 'Georgia'), ('HI', 'Hawaii'),
    ('ID', 'Idaho'), ('IL', 'Illinois'), ('IN', 'Indiana'), ('IA', 'Iowa'),
    ('KS', 'Kansas'), ('KY', 'Kentucky'), ('LA', 'Louisiana'), ('ME', 'Maine'),
    ('MD', 'Maryland'), ('MA', 'Massachusetts'), ('MI', 'Michigan'), ('MN', 'Minnesota'),
    ('MS', 'Mississippi'), ('MO', 'Missouri'), ('MT', 'Montana'), ('NE', 'Nebraska'),
    ('NV', 'Nevada'), ('NH', 'New Hampshire'), ('NJ', 'New Jersey'), ('NM', 'New Mexico'),
    ('NY', 'New York'), ('NC', 'North Carolina'), ('ND', 'North Dakota'), ('OH', 'Ohio'),
    ('OK', 'Oklahoma'), ('OR', 'Oregon'), ('PA', 'Pennsylvania'), ('PR', 'Puerto Rico'),
    ('RI', 'Rhode Island'), ('SC', 'South Carolina'), ('SD', 'South Dakota'), ('TN', 'Tennessee'),
    ('TX', 'Texas'), ('UT', 'Utah'), ('VT', 'Vermont'), ('VA', 'Virginia'),
    ('WA', 'Washington'), ('WV', 'West Virginia'), ('WI', 'Wisconsin'), ('WY', 'Wyoming'),
]

PREMIUM_BY_CODE = {
    'CA': [
        {'suffix': 'DMV_POLY', 'label': 'DMV Polycarbonate', 'production_code': 'DMV'},
        {'suffix': 'ID_IDENTICAL_DMV_POLY', 'label': 'ID Identical — DMV Polycarbonate', 'production_code': 'DMV', 'doc_type': 'id'},
    ],
    'CT': [{'suffix': 'POLY', 'label': 'Polycarbonate (Official)'}],
    'ID': [{'suffix': 'POLY', 'label': 'Polycarbonate (Official)'}],
    'IL': [{'suffix': 'ID_IDENTICAL_DMV_POLY', 'label': 'ID Identical — DMV Polycarbonate', 'production_code': 'DMV', 'doc_type': 'id'}],
    'IA': [{'suffix': 'POLY', 'label': 'Polycarbonate (Official)'}],
    'KS': [{'suffix': 'POLY', 'label': 'Polycarbonate (Official)'}],
    'ME': [{'suffix': 'POLY', 'label': 'Polycarbonate (Official)'}],
    'MA': [{'suffix': 'ID_IDENTICAL_RMV_POLY', 'label': 'ID Identical — RMV Polycarbonate', 'production_code': 'RMV', 'doc_type': 'id'}],
    'MI': [{'suffix': 'ID_IDENTICAL_DMV_POLY', 'label': 'ID Identical — DMV Polycarbonate', 'production_code': 'DMV', 'doc_type': 'id'}],
    'MN': [{'suffix': 'ID_IDENTICAL_DMV_POLY', 'label': 'ID Identical — DMV Polycarbonate', 'production_code': 'DMV', 'doc_type': 'id'}],
    'MS': [{'suffix': 'ID_IDENTICAL_DPS_POLY', 'label': 'ID Identical — DPS Polycarbonate', 'production_code': 'DPS', 'doc_type': 'id'}],
    'MO': [{'suffix': 'POLY', 'label': 'Polycarbonate (Official)'}],
    'MT': [{'suffix': 'POLY', 'label': 'Polycarbonate (Official)'}],
    'NE': [{'suffix': 'POLY', 'label': 'Polycarbonate (Official)'}],
    'NV': [{'suffix': 'ID_IDENTICAL_DMV_POLY', 'label': 'ID Identical — DMV Polycarbonate', 'production_code': 'DMV', 'doc_type': 'id'}],
    'NJ': [{'suffix': 'ID_IDENTICAL_MVC_POLY', 'label': 'NJ ID Identical — MVC Polycarbonate', 'production_code': 'MVC', 'doc_type': 'id'}],
    'NC': [{'suffix': 'POLY', 'label': 'Polycarbonate (Official)'}],
    'OK': [{'suffix': 'POLY', 'label': 'Polycarbonate (Official)'}],
    'RI': [{'suffix': 'POLY', 'label': 'Polycarbonate (Official)'}],
    'TN': [{'suffix': 'ID_ONLY', 'label': 'Identification Card Only', 'doc_type': 'id'}],
    'UT': [{'suffix': 'ID_IDENTICAL_DMV_POLY', 'label': 'ID Identical — DMV Polycarbonate', 'production_code': 'DMV', 'doc_type': 'id'}],
    'WV': [{'suffix': 'POLY', 'label': 'Polycarbonate (Official)'}],
}

CDL_REGIONS = [('CA', 'California'), ('GA', 'Georgia'), ('OH', 'Ohio')]

LEGACY_STATE_TO_PRODUCT = {
    'Pennsylvania': 'PA:STANDARD',
    'New Jersey': 'NJ:STANDARD',
    'Old Maine': 'ME:STANDARD',
    'Maine': 'ME:STANDARD',
    'Washington': 'WA:STANDARD',
    'Oregon': 'OR:STANDARD',
    'South Carolina': 'SC:STANDARD',
    'Missouri': 'MO:STANDARD',
    'Illinois': 'IL:STANDARD',
    'Connecticut': 'CT:STANDARD',
    'Arizona': 'AZ:STANDARD',
    'Florida': 'FL:STANDARD',
    'Texas': 'TX:STANDARD',
    'TEST_DONT_ORDER': 'TEST:DONT_ORDER',
}

# Legacy STATE_PRICES keys for backward-compatible lookup by display name
LEGACY_STATE_PRICES = {
    'TEST_DONT_ORDER': 1,
    **{name: REGION_STANDARD_PRICES.get(name, DEFAULT_STANDARD_PRICE) for _, name in US_REGIONS},
    'Old Maine': REGION_STANDARD_PRICES.get('Maine', DEFAULT_STANDARD_PRICE),
}


def _standard_price(region: str) -> float:
    return float(REGION_STANDARD_PRICES.get(region, DEFAULT_STANDARD_PRICE))


def _premium_price(region: str, add: float = PREMIUM_PRICE_ADD) -> float:
    return _standard_price(region) + add


def _build_catalog() -> dict:
    products = {}

    for code, name in US_REGIONS:
        base = _standard_price(name)
        products[f'{code}:STANDARD'] = {
            'id': f'{code}:STANDARD',
            'region': name,
            'category': 'us_standard',
            'label': 'Standard',
            'price': base,
        }
        for prem in PREMIUM_BY_CODE.get(code, []):
            pid = f"{code}:{prem['suffix']}"
            price_add = prem.get('price_add', PREMIUM_PRICE_ADD)
            products[pid] = {
                'id': pid,
                'region': name,
                'category': 'us_premium',
                'label': prem['label'],
                'price': _premium_price(name, price_add),
            }

    for code, name in CDL_REGIONS:
        pid = f'{code}:CDL_POLY'
        products[pid] = {
            'id': pid,
            'region': name,
            'category': 'cdl',
            'label': 'CDL Polycarbonate (Official)',
            'price': _standard_price(name) + CDL_PRICE_ADD,
        }

    products['UK:ID_IDENTICAL_POLY'] = {
        'id': 'UK:ID_IDENTICAL_POLY',
        'region': 'United Kingdom',
        'category': 'international',
        'label': 'UK ID Identical Polycarbonate',
        'price': UK_BASE_PRICE,
    }
    products['UK:PROVISIONAL_POLY'] = {
        'id': 'UK:PROVISIONAL_POLY',
        'region': 'United Kingdom',
        'category': 'international',
        'label': 'UK Provisional (Polycarbonate)',
        'price': UK_BASE_PRICE,
    }
    products['TEST:DONT_ORDER'] = {
        'id': 'TEST:DONT_ORDER',
        'region': 'Test',
        'category': 'us_standard',
        'label': 'Test (do not order)',
        'price': 1,
    }

    return products


PRODUCT_BY_ID = _build_catalog()
REGION_TO_STANDARD = {
    name: f'{code}:STANDARD' for code, name in US_REGIONS
}


def resolve_product_id(raw) -> str:
    if not raw:
        return DEFAULT_PRODUCT_ID
    raw = str(raw).strip()
    if raw in PRODUCT_BY_ID:
        return raw
    if raw in LEGACY_STATE_TO_PRODUCT:
        return LEGACY_STATE_TO_PRODUCT[raw]
    if raw in REGION_TO_STANDARD:
        return REGION_TO_STANDARD[raw]
    return DEFAULT_PRODUCT_ID


def get_product_list_price(product_id: str) -> float:
    product = PRODUCT_BY_ID.get(product_id)
    if product:
        return float(product['price'])
    return float(DEFAULT_STANDARD_PRICE)


def item_list_price(item: dict) -> float:
    """List price for one ids[] line — prefers productId, falls back to legacy state label."""
    product_id = resolve_product_id(item.get('productId') or item.get('state', ''))
    return get_product_list_price(product_id)


def is_test_product(item: dict) -> bool:
    product_id = resolve_product_id(item.get('productId') or item.get('state', ''))
    return product_id == 'TEST:DONT_ORDER'
