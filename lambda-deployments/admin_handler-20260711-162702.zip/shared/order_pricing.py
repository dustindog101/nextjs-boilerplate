"""
Server-side order pricing — shared by Create Order Lambda only.
No crypto / payment-gateway dependencies. Safe to deploy without payment_shared/.
Keep tier logic in sync with lib/pricing.ts.
"""

import datetime

from shared.product_catalog import (
    DEFAULT_STANDARD_PRICE,
    item_list_price,
    is_test_product,
)

DEFAULT_ID_PRICE = DEFAULT_STANDARD_PRICE
HANDLING_FEE = 5
SHIPPING_FEE = 15

RETAIL_VOLUME_DISCOUNTS = {
    'single': 0,
    'two_to_three': 10,
    'four_plus': 20,
}

RESELLER_WHOLESALE_TIERS = [
    {'min_ids': 1, 'max_ids': 4, 'per_id': 65},
    {'min_ids': 5, 'max_ids': 9, 'per_id': 60},
    {'min_ids': 10, 'max_ids': 19, 'per_id': 55},
    {'min_ids': 20, 'max_ids': 10**9, 'per_id': 45},
]

RESELLER_PORTAL_SOURCE = 'reseller_portal'
USERNAME_INDEX = 'UsernameIndex'
DEFAULT_RESELLER_RETAIL_PER_ID = 95.0


def _lookup_user(users_table, user_id):
    """
    idPirate_users uses composite PK (userId + username).
    GetItem with userId alone raises ValidationException — Query partition key or UsernameIndex.
    """
    if not users_table or not user_id:
        return None

    from boto3.dynamodb.conditions import Key

    uid = str(user_id).strip()
    try:
        qr = users_table.query(KeyConditionExpression=Key('userId').eq(uid))
        items = qr.get('Items', [])
        if items:
            return items[0]
    except Exception as exc:
        print(f'[order_pricing] userId query failed: {exc}')

    try:
        qr = users_table.query(
            IndexName=USERNAME_INDEX,
            KeyConditionExpression=Key('username').eq(uid.lower()),
        )
        items = qr.get('Items', [])
        if items:
            return items[0]
    except Exception as exc:
        print(f'[order_pricing] UsernameIndex query failed: {exc}')

    return None


def _user_is_reseller(users_table, user_id):
    user = _lookup_user(users_table, user_id)
    return bool(user and user.get('isReseller') is True)


def shipping_is_delivery(shipping) -> bool:
    if not shipping:
        return False
    if isinstance(shipping, str):
        normalized = shipping.strip().lower()
        if normalized in ('local delivery', 'local pickup'):
            return False
    return True


def retail_discount_per_id(id_count: int) -> float:
    if id_count <= 1:
        return float(RETAIL_VOLUME_DISCOUNTS['single'])
    if id_count <= 3:
        return float(RETAIL_VOLUME_DISCOUNTS['two_to_three'])
    return float(RETAIL_VOLUME_DISCOUNTS['four_plus'])


def wholesale_per_id(id_count: int) -> float:
    n = max(int(id_count), 1)
    for tier in RESELLER_WHOLESALE_TIERS:
        if tier['min_ids'] <= n <= tier['max_ids']:
            return float(tier['per_id'])
    return float(RESELLER_WHOLESALE_TIERS[-1]['per_id'])


def resolve_pricing_mode(order_data, users_table=None):
    """Server-side pricing path: retail vs reseller wholesale."""
    source = order_data.get('source')
    if source == RESELLER_PORTAL_SOURCE:
        return 'reseller_wholesale'

    user_id = order_data.get('userId')
    if not user_id or not users_table:
        return 'retail'

    if _user_is_reseller(users_table, user_id):
        return 'reseller_wholesale'

    return 'retail'


def pricing_mode_from_order(order, users_table=None):
    """For payment re-pricing: prefer stored mode, else infer."""
    price = order.get('price') or {}
    stored = price.get('pricingMode')
    if stored in ('retail', 'reseller_wholesale'):
        return stored

    source = order.get('source')
    if source == RESELLER_PORTAL_SOURCE:
        return 'reseller_wholesale'

    user_id = order.get('userId')
    if user_id and users_table and _user_is_reseller(users_table, user_id):
        return 'reseller_wholesale'

    return 'retail'


def get_reseller_retail_per_id(users_table, reseller_slug):
    """Public retail per-ID for a reseller slug; None if not a reseller."""
    user = _lookup_user(users_table, reseller_slug)
    if not user or user.get('isReseller') is not True:
        return None
    rp = user.get('resellerPricing') or {}
    val = rp.get('defaultPerId')
    if val is not None:
        return float(val)
    return float(DEFAULT_RESELLER_RETAIL_PER_ID)


def calc_reseller_portal_prices(
    ids_list,
    shipping_is_delivery_flag,
    users_table,
    reseller_id,
    client_customer_total=None,
):
    """
    Dual snapshots for white-label orders: customerPrice (retail) + wholesaleCost (platform).
    price.total follows customer total for crypto compatibility.
    """
    id_count = len(ids_list)
    wholesale_price = calc_order_usd_total(
        ids_list,
        shipping_is_delivery_flag,
        None,
        None,
        'reseller_wholesale',
    )
    retail_per_id = get_reseller_retail_per_id(users_table, reseller_id)
    if retail_per_id is None:
        retail_per_id = float(DEFAULT_RESELLER_RETAIL_PER_ID)

    id_subtotal = round(retail_per_id * id_count, 2)
    shipping = SHIPPING_FEE if shipping_is_delivery_flag else 0.0
    handling = HANDLING_FEE
    customer_total = round(id_subtotal + handling + shipping, 2)

    if client_customer_total is not None:
        if abs(float(client_customer_total) - customer_total) > 0.02:
            raise ValueError('Customer price does not match server calculation.')

    customer_price = {
        'idSubtotal': id_subtotal,
        'subtotal': id_subtotal,
        'retailPerId': retail_per_id,
        'idCount': id_count,
        'handling': handling,
        'shipping': round(shipping, 2),
        'total': customer_total,
    }
    wholesale_cost = {
        'idSubtotal': wholesale_price['idSubtotal'],
        'subtotal': wholesale_price['idSubtotal'],
        'total': wholesale_price['total'],
        'perIdEffective': wholesale_price['perIdEffective'],
        'idCount': id_count,
        'pricingMode': 'reseller_wholesale',
        'handling': wholesale_price['handling'],
        'shipping': wholesale_price['shipping'],
    }
    price = dict(customer_price)
    price['pricingMode'] = 'reseller_wholesale'
    price['idCount'] = id_count
    price['perIdEffective'] = retail_per_id

    return {
        'price': price,
        'customerPrice': customer_price,
        'wholesaleCost': wholesale_cost,
    }


def calc_order_usd_total(
    ids_list,
    shipping_is_delivery: bool,
    discount_code=None,
    discounts_table=None,
    pricing_mode='retail',
):
    """Server-side pricing from ids[] + fees − discount."""
    id_count = len(ids_list)
    list_subtotal = 0.0
    id_subtotal = 0.0

    if pricing_mode == 'reseller_wholesale':
        per_id = wholesale_per_id(id_count)
        for item in ids_list:
            list_subtotal += item_list_price(item)
        id_subtotal = per_id * id_count
    else:
        discount_per_id = retail_discount_per_id(id_count)
        for item in ids_list:
            base = item_list_price(item)
            list_subtotal += base
            if is_test_product(item):
                id_subtotal += base
            else:
                id_subtotal += max(base - discount_per_id, 0.0)

    list_subtotal = round(list_subtotal, 2)
    id_subtotal = round(id_subtotal, 2)
    volume_savings = round(max(list_subtotal - id_subtotal, 0.0), 2) if pricing_mode == 'retail' else 0.0

    shipping = SHIPPING_FEE if shipping_is_delivery else 0.0
    order_total = id_subtotal + HANDLING_FEE + shipping

    discount_amount = 0.0
    if discount_code and discounts_table:
        discount_amount = _validate_discount_amount(discount_code, order_total, discounts_table)

    total = round(order_total - discount_amount, 2)
    per_id_effective = round(id_subtotal / id_count, 2) if id_count else 0.0

    result = {
        'subtotal': id_subtotal,
        'idSubtotal': id_subtotal,
        'listSubtotal': list_subtotal,
        'volumeSavings': volume_savings,
        'idCount': id_count,
        'pricingMode': pricing_mode,
        'perIdEffective': per_id_effective,
        'handling': HANDLING_FEE,
        'shipping': round(shipping, 2),
        'total': total,
        'discountAmount': round(discount_amount, 2),
    }
    return result


def _validate_discount_amount(code, order_total, discounts_table):
    code = code.strip().upper()
    resp = discounts_table.get_item(Key={'code': code})
    d = resp.get('Item')
    if not d or not d.get('isActive', True):
        raise ValueError('Invalid or inactive discount code.')

    expires_at = d.get('expiresAt')
    if expires_at:
        exp_dt = datetime.datetime.fromisoformat(expires_at.replace('Z', '+00:00'))
        if exp_dt.tzinfo is None:
            exp_dt = exp_dt.replace(tzinfo=datetime.timezone.utc)
        if datetime.datetime.now(datetime.timezone.utc) > exp_dt:
            raise ValueError('Discount code has expired.')

    max_uses = d.get('maxUses')
    if max_uses is not None and int(d.get('usedCount', 0)) >= int(max_uses):
        raise ValueError('Discount code has reached its usage limit.')

    min_order = float(d.get('minOrder', 0))
    if order_total < min_order:
        raise ValueError(f'Minimum order of ${min_order:.2f} required for this code.')

    discount_type = d.get('discountType', 'percentage')
    discount_value = float(d.get('value', 0))
    if discount_type == 'percentage':
        return round(order_total * (discount_value / 100), 2)
    return min(discount_value, order_total)
