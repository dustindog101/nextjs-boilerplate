# Core shared modules (order pricing, etc.) — no payment-gateway dependency.
