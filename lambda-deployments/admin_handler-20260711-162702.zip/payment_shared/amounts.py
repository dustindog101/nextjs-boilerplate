"""Crypto-denominated unique amount generation."""

import json
import math
import os
import random
import urllib.error
import urllib.request
from decimal import Decimal, ROUND_DOWN

from .config import ASSETS
from .pricing import calc_order_usd_total


def fetch_coingecko_rates():
    ids = ','.join(sorted({a['coingecko_id'] for a in ASSETS.values()}))
    url = f'https://api.coingecko.com/api/v3/simple/price?ids={ids}&vs_currencies=usd'
    api_key = os.environ.get('COINGECKO_API_KEY')
    if api_key:
        url += f'&x_cg_demo_api_key={api_key}'
    req = urllib.request.Request(url, headers={'Accept': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode())
    except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError, TimeoutError) as e:
        raise ValueError(f'Unable to fetch exchange rates: {e}') from e


def get_rate_for_asset(asset_id, rates):
    meta = ASSETS[asset_id]
    cg = meta['coingecko_id']
    rate = rates.get(cg, {}).get('usd')
    if not rate or float(rate) <= 0:
        raise ValueError(f'Unable to fetch exchange rate for {asset_id}.')
    return float(rate)


def atomic_to_decimal(atomic: int, decimals: int) -> str:
    if decimals == 0:
        return str(atomic)
    whole = atomic // (10 ** decimals)
    frac = atomic % (10 ** decimals)
    return f'{whole}.{str(frac).zfill(decimals)}'


def compute_unique_amount(asset_id: str, usd_total: float, rates: dict):
    meta = ASSETS[asset_id]
    decimals = meta['decimals']
    rate = get_rate_for_asset(asset_id, rates)
    factor = 10 ** decimals
    base_atomic = int(math.floor((usd_total / rate) * factor))
    if base_atomic < 1:
        raise ValueError('Order total too small for this asset.')

    for _ in range(5):
        suffix = random.randint(1, 9999)
        expected_atomic = base_atomic + suffix
        expected_amount = atomic_to_decimal(expected_atomic, decimals)
        return {
            'expectedAtomic': str(expected_atomic),
            'expectedAmount': expected_amount,
            'uniqueSuffix': suffix,
            'exchangeRate': rate,
            'baseTotalUsd': round(usd_total, 2),
        }
    raise ValueError('Could not generate unique payment amount; try again.')
