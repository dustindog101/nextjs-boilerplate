"""Payment request handlers for LOOKUP Lambda."""

import datetime
import uuid

from boto3.dynamodb.conditions import Key, Attr  # noqa: F401 — Attr used in _atomic_collision

from .config import ASSETS, INTENTS_TABLE, ORDERS_TABLE, SETTINGS_TABLE
from .amounts import fetch_coingecko_rates, compute_unique_amount
from .pricing import calc_order_usd_total, pricing_mode_from_order
from .gateway import is_crypto_payments_enabled, is_resource_not_found, safe_get_settings
from .settings import (
    list_enabled_crypto_methods,
    now_iso,
    compute_expires_at,
    sanitize_intent_for_client,
)
from .validation import validate_address
from .dynamo import to_dynamo_number


ACTIVE_STATUSES = ('pending', 'detected')


def _shipping_is_delivery(shipping):
    if not shipping:
        return False
    if isinstance(shipping, str):
        normalized = shipping.strip().lower()
        if normalized in ('local delivery', 'local pickup'):
            return False
    return True


def handle_list_crypto_methods(settings_table):
    if not is_crypto_payments_enabled():
        return {'methods': [], 'enabled': False}
    settings = safe_get_settings(settings_table)
    methods = list_enabled_crypto_methods(settings)
    return {'methods': methods, 'enabled': len(methods) > 0}


def _get_active_intent_for_order(intents_table, order_id):
    resp = intents_table.query(
        IndexName='OrderIdIndex',
        KeyConditionExpression=Key('orderId').eq(order_id),
    )
    for item in resp.get('Items', []):
        if item.get('status') in ACTIVE_STATUSES:
            return item
    return None


def _require_gateway():
    if not is_crypto_payments_enabled():
        raise ValueError('Crypto payments are not enabled on this deployment.')


def handle_create_payment_intent(
    body,
    user_id,
    settings_table,
    intents_table,
    orders_table,
    discounts_table,
    users_table=None,
):
    _require_gateway()
    order_id = body.get('orderId')
    asset = body.get('asset')
    if not order_id or not asset:
        raise ValueError("Missing 'orderId' or 'asset'.")
    if asset not in ASSETS:
        raise ValueError(f"Unknown asset: {asset}.")

    order_resp = orders_table.get_item(Key={'orderId': order_id})
    order = order_resp.get('Item')
    if not order:
        raise ValueError(f"Order '{order_id}' not found.")
    if order.get('userId') != user_id:
        raise PermissionError('Access denied.')
    if order.get('paymentStatus') == 'Paid':
        raise ValueError('Order is already paid.')

    existing = _get_active_intent_for_order(intents_table, order_id)
    if existing:
        raise ValueError('An active payment invoice already exists. Cancel it before creating a new one.')

    settings = safe_get_settings(settings_table)
    gw = settings['paymentGateways'].get(asset, {})
    if not gw.get('enabled') or not gw.get('address'):
        raise ValueError(f'Payment method {asset} is not enabled.')

    deposit_address = gw['address'].strip()
    if not validate_address(asset, deposit_address):
        raise ValueError('Configured deposit address is invalid.')

    shipping = order.get('shipping')
    shipping_is_delivery = _shipping_is_delivery(shipping)
    customer_price = order.get('customerPrice') or {}
    cp_total = customer_price.get('total')
    if cp_total is not None:
        usd_total = float(cp_total)
    else:
        discount_code = order.get('discountCode')
        pricing_mode = pricing_mode_from_order(order, users_table)
        price = calc_order_usd_total(
            order.get('ids', []),
            shipping_is_delivery,
            discount_code,
            discounts_table,
            pricing_mode,
        )
        usd_total = price['total']

    rates = fetch_coingecko_rates()
    amount_data = None
    intent_id = str(uuid.uuid4())
    created = now_iso()
    ttl_hours = int(settings.get('paymentIntentTtlHours', 48))
    order_exp = order.get('paymentExpiresAt')
    expires_at = compute_expires_at(ttl_hours, order_exp)

    def _atomic_collision(deposit, atomic):
        scan = intents_table.scan(
            FilterExpression=Attr('depositAddress').eq(deposit)
            & Attr('expectedAtomic').eq(atomic)
            & Attr('status').is_in(list(ACTIVE_STATUSES)),
            Limit=1,
        )
        return len(scan.get('Items', [])) > 0

    for attempt in range(5):
        amount_data = compute_unique_amount(asset, usd_total, rates)
        if _atomic_collision(deposit_address, amount_data['expectedAtomic']):
            continue
        item = {
            'intentId': intent_id,
            'orderId': order_id,
            'userId': user_id,
            'rail': 'crypto',  # extensible: future zelle/cashapp self-hosted rails
            'asset': asset,
            'depositAddress': deposit_address,
            'expectedAmount': amount_data['expectedAmount'],
            'expectedAtomic': amount_data['expectedAtomic'],
            'uniqueSuffix': int(amount_data['uniqueSuffix']),
            'baseTotalUsd': to_dynamo_number(amount_data['baseTotalUsd']),
            'exchangeRate': to_dynamo_number(amount_data['exchangeRate']),
            'status': 'pending',
            'confirmations': 0,
            'expiresAt': expires_at,
            'createdAt': created,
        }
        try:
            intents_table.put_item(
                Item=item,
                ConditionExpression=Attr('intentId').not_exists(),
            )
            break
        except intents_table.meta.client.exceptions.ConditionalCheckFailedException:
            intent_id = str(uuid.uuid4())
            continue
    else:
        raise ValueError('Could not create payment invoice; try again.')

    orders_table.update_item(
        Key={'orderId': order_id},
        UpdateExpression='SET paymentIntentId = :pid, cryptoAsset = :asset, updatedAt = :u',
        ExpressionAttributeValues={
            ':pid': intent_id,
            ':asset': asset,
            ':u': now_iso(),
        },
    )

    return sanitize_intent_for_client(item)


def handle_reseller_get_payment_intent(body, intents_table, orders_table):
    """Reseller JWT: read invoice when reseller owns the order (no userId match)."""
    _require_gateway()
    order_id = body.get('orderId')
    if not order_id:
        raise ValueError("Missing 'orderId'.")

    order_resp = orders_table.get_item(Key={'orderId': order_id})
    order = order_resp.get('Item')
    if not order:
        raise ValueError(f"Order '{order_id}' not found.")

    intent_id = order.get('paymentIntentId')
    if not intent_id:
        active = _get_active_intent_for_order(intents_table, order_id)
        if active:
            return {'intent': sanitize_intent_for_client(active)}
        return {'intent': None}

    resp = intents_table.get_item(Key={'intentId': intent_id})
    intent = resp.get('Item')
    if not intent:
        return {'intent': None}

    return {'intent': sanitize_intent_for_client(intent)}


def handle_get_payment_intent(body, user_id, intents_table, orders_table):
    _require_gateway()
    order_id = body.get('orderId')
    if not order_id:
        raise ValueError("Missing 'orderId'.")

    order_resp = orders_table.get_item(Key={'orderId': order_id})
    order = order_resp.get('Item')
    if not order:
        raise ValueError(f"Order '{order_id}' not found.")
    if order.get('userId') != user_id:
        raise PermissionError('Access denied.')

    intent_id = order.get('paymentIntentId')
    if not intent_id:
        return {'intent': None}

    resp = intents_table.get_item(Key={'intentId': intent_id})
    intent = resp.get('Item')
    if not intent:
        return {'intent': None}

    return {'intent': sanitize_intent_for_client(intent)}


def handle_cancel_payment_intent(body, user_id, intents_table, orders_table):
    _require_gateway()
    order_id = body.get('orderId')
    if not order_id:
        raise ValueError("Missing 'orderId'.")

    order_resp = orders_table.get_item(Key={'orderId': order_id})
    order = order_resp.get('Item')
    if not order:
        raise ValueError(f"Order '{order_id}' not found.")
    if order.get('userId') != user_id:
        raise PermissionError('Access denied.')

    intent = _get_active_intent_for_order(intents_table, order_id)
    if not intent:
        return {'message': 'No active payment invoice to cancel.'}

    cancelled_at = now_iso()
    intents_table.update_item(
        Key={'intentId': intent['intentId']},
        UpdateExpression='SET #s = :cancelled, cancelledAt = :c',
        ExpressionAttributeNames={'#s': 'status'},
        ExpressionAttributeValues={':cancelled': 'cancelled', ':c': cancelled_at},
    )

    orders_table.update_item(
        Key={'orderId': order_id},
        UpdateExpression='REMOVE paymentIntentId, cryptoAsset SET updatedAt = :u',
        ExpressionAttributeValues={':u': cancelled_at},
    )

    return {'message': 'Payment invoice cancelled.', 'intentId': intent['intentId']}


def handle_admin_get_payment_intent(body, intents_table, orders_table):
    """Admin: load invoice without user ownership check."""
    _require_gateway()
    order_id = body.get('orderId')
    if not order_id:
        raise ValueError("Missing 'orderId'.")

    order_resp = orders_table.get_item(Key={'orderId': order_id})
    order = order_resp.get('Item')
    if not order:
        raise ValueError(f"Order '{order_id}' not found.")

    intent_id = order.get('paymentIntentId')
    if not intent_id:
        active = _get_active_intent_for_order(intents_table, order_id)
        if active:
            return {'intent': sanitize_intent_for_client(active)}
        return {'intent': None}

    resp = intents_table.get_item(Key={'intentId': intent_id})
    intent = resp.get('Item')
    if not intent:
        return {'intent': None}

    return {'intent': sanitize_intent_for_client(intent)}


def handle_admin_create_payment_intent(
    body, settings_table, intents_table, orders_table, discounts_table
):
    """Admin: create invoice using the order owner's userId."""
    order_id = body.get('orderId')
    if not order_id:
        raise ValueError("Missing 'orderId'.")
    order_resp = orders_table.get_item(Key={'orderId': order_id})
    order = order_resp.get('Item')
    if not order:
        raise ValueError(f"Order '{order_id}' not found.")
    user_id = order.get('userId')
    if not user_id:
        raise ValueError('Order has no userId.')
    return handle_create_payment_intent(
        body, user_id, settings_table, intents_table, orders_table, discounts_table
    )


def handle_admin_cancel_payment_intent(body, intents_table, orders_table):
    """Admin: cancel active invoice without user ownership check."""
    _require_gateway()
    order_id = body.get('orderId')
    if not order_id:
        raise ValueError("Missing 'orderId'.")

    order_resp = orders_table.get_item(Key={'orderId': order_id})
    order = order_resp.get('Item')
    if not order:
        raise ValueError(f"Order '{order_id}' not found.")

    intent = _get_active_intent_for_order(intents_table, order_id)
    if not intent:
        intent_id = order.get('paymentIntentId')
        if intent_id:
            resp = intents_table.get_item(Key={'intentId': intent_id})
            intent = resp.get('Item')
            if intent and intent.get('status') not in ACTIVE_STATUSES:
                intent = None
    if not intent:
        return {'message': 'No active payment invoice to cancel.'}

    cancelled_at = now_iso()
    intents_table.update_item(
        Key={'intentId': intent['intentId']},
        UpdateExpression='SET #s = :cancelled, cancelledAt = :c',
        ExpressionAttributeNames={'#s': 'status'},
        ExpressionAttributeValues={':cancelled': 'cancelled', ':c': cancelled_at},
    )

    orders_table.update_item(
        Key={'orderId': order_id},
        UpdateExpression='REMOVE paymentIntentId, cryptoAsset SET updatedAt = :u',
        ExpressionAttributeValues={':u': cancelled_at},
    )

    return {'message': 'Payment invoice cancelled.', 'intentId': intent['intentId']}
