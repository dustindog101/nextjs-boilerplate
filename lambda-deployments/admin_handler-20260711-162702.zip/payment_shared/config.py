"""Asset metadata — keep in sync with lib/paymentConstants.ts."""

ASSETS = {
    'btc': {
        'label': 'Bitcoin',
        'symbol': 'BTC',
        'icon': '₿',
        'decimals': 8,
        'coingecko_id': 'bitcoin',
        'default_confirmations': 1,
        'family': 'esplora',
        'esplora_base': 'https://blockstream.info/api',
    },
    'ltc': {
        'label': 'Litecoin',
        'symbol': 'LTC',
        'icon': 'Ł',
        'decimals': 8,
        'coingecko_id': 'litecoin',
        'default_confirmations': 1,
        'family': 'esplora',
        'esplora_base': 'https://litecoinspace.org/api',
    },
    'sol': {
        'label': 'Solana',
        'symbol': 'SOL',
        'icon': '◎',
        'decimals': 9,
        'coingecko_id': 'solana',
        'default_confirmations': 1,
        'family': 'solana',
    },
    'usdc_ethereum': {
        'label': 'USDC (Ethereum)',
        'symbol': 'USDC',
        'icon': '$',
        'decimals': 6,
        'coingecko_id': 'usd-coin',
        'default_confirmations': 12,
        'family': 'etherscan',
        'chain_id': 1,
        'contract': '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48',
    },
    'usdc_polygon': {
        'label': 'USDC (Polygon)',
        'symbol': 'USDC',
        'icon': '$',
        'decimals': 6,
        'coingecko_id': 'usd-coin',
        'default_confirmations': 12,
        'family': 'etherscan',
        'chain_id': 137,
        'contract': '0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359',
    },
    'usdc_base': {
        'label': 'USDC (Base)',
        'symbol': 'USDC',
        'icon': '$',
        'decimals': 6,
        'coingecko_id': 'usd-coin',
        'default_confirmations': 12,
        'family': 'etherscan',
        'chain_id': 8453,
        'contract': '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
    },
    'usdc_solana': {
        'label': 'USDC (Solana)',
        'symbol': 'USDC',
        'icon': '$',
        'decimals': 6,
        'coingecko_id': 'usd-coin',
        'default_confirmations': 1,
        'family': 'solana_usdc',
        'mint': 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
    },
}

ASSET_IDS = list(ASSETS.keys())
DEFAULT_TTL_HOURS = 48
SETTINGS_PK = 'site'
SETTINGS_TABLE = 'idPirate_settings'
INTENTS_TABLE = 'idPirate_payment_intents'
ORDERS_TABLE = 'idPirate_orders'
DISCOUNTS_TABLE = 'idPirate_discounts'
