"""Feature flag + safe DynamoDB access for optional crypto payment gateway."""

import os

from botocore.exceptions import ClientError

# Set CRYPTO_PAYMENTS_ENABLED=false on Lambda to disable gateway without redeploying handlers.
_ENABLED_ENV = os.environ.get('CRYPTO_PAYMENTS_ENABLED', 'true').lower() not in ('0', 'false', 'no')


def is_crypto_payments_enabled() -> bool:
    return _ENABLED_ENV


def is_resource_not_found(exc: BaseException) -> bool:
    if isinstance(exc, ClientError):
        return exc.response.get('Error', {}).get('Code') == 'ResourceNotFoundException'
    return False


def safe_get_settings(settings_table):
    from .settings import get_settings, default_settings

    if not is_crypto_payments_enabled():
        return default_settings()
    try:
        return get_settings(settings_table)
    except ClientError as e:
        if is_resource_not_found(e):
            return default_settings()
        raise
