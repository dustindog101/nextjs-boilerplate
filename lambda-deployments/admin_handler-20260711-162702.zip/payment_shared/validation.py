"""Address format validation for payment gateway settings."""

import re

_BTC_RE = re.compile(r'^(bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}$')
_LTC_RE = re.compile(r'^(ltc1|[LM3])[a-zA-HJ-NP-Z0-9]{25,62}$')
_SOL_RE = re.compile(r'^[1-9A-HJ-NP-Za-km-z]{32,44}$')
_EVM_RE = re.compile(r'^0x[a-fA-F0-9]{40}$')


def validate_address(asset_id: str, address: str) -> bool:
    address = (address or '').strip()
    if not address:
        return False
    if asset_id == 'btc':
        return bool(_BTC_RE.match(address))
    if asset_id == 'ltc':
        return bool(_LTC_RE.match(address))
    if asset_id in ('sol', 'usdc_solana'):
        return bool(_SOL_RE.match(address))
    if asset_id in ('usdc_ethereum', 'usdc_polygon', 'usdc_base'):
        return bool(_EVM_RE.match(address))
    return False


def validate_gateway_settings(gateways: dict) -> list:
    """Return list of error strings; empty if valid."""
    from .config import ASSET_IDS

    errors = []
    for asset_id in ASSET_IDS:
        cfg = gateways.get(asset_id) or {}
        enabled = bool(cfg.get('enabled'))
        address = (cfg.get('address') or '').strip()
        if enabled and not address:
            errors.append(f'{asset_id}: address required when enabled.')
        elif enabled and not validate_address(asset_id, address):
            errors.append(f'{asset_id}: invalid address format.')
    return errors
