"""DynamoDB type helpers — boto3 rejects Python float; use Decimal."""

from decimal import Decimal


def to_dynamo_number(value):
    """Convert int/float/str to a DynamoDB-safe numeric type."""
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return Decimal(str(value))
    if isinstance(value, Decimal):
        return value
    if isinstance(value, str) and value.strip():
        return Decimal(value)
    return value


def from_dynamo_number(value):
    """Convert DynamoDB Decimal to JSON-serializable float."""
    if isinstance(value, Decimal):
        return float(value)
    return value
