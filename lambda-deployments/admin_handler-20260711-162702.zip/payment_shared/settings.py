"""Settings and payment intent helpers."""

import datetime
import uuid

from .config import ASSETS, ASSET_IDS, DEFAULT_TTL_HOURS, SETTINGS_PK
from .dynamo import from_dynamo_number


def default_gateways():
    return {
        aid: {
            'enabled': False,
            'address': '',
            'minConfirmations': ASSETS[aid]['default_confirmations'],
        }
        for aid in ASSET_IDS
    }


def default_settings():
    return {
        'pk': SETTINGS_PK,
        'paymentGateways': default_gateways(),
        'paymentIntentTtlHours': DEFAULT_TTL_HOURS,
    }


def get_settings(settings_table):
    resp = settings_table.get_item(Key={'pk': SETTINGS_PK})
    item = resp.get('Item')
    if not item:
        return default_settings()
    gateways = item.get('paymentGateways') or {}
    merged = default_gateways()
    for aid in ASSET_IDS:
        if aid in gateways:
            merged[aid].update(gateways[aid])
    item['paymentGateways'] = merged
    if 'paymentIntentTtlHours' not in item:
        item['paymentIntentTtlHours'] = DEFAULT_TTL_HOURS
    return item


def is_gateway_enabled(settings, asset_id):
    cfg = settings.get('paymentGateways', {}).get(asset_id, {})
    return bool(cfg.get('enabled') and cfg.get('address'))


def list_enabled_asset_ids(settings):
    return [aid for aid in ASSET_IDS if is_gateway_enabled(settings, aid)]


def list_enabled_crypto_methods(settings):
    methods = []
    for aid in list_enabled_asset_ids(settings):
        meta = ASSETS[aid]
        methods.append({
            'id': aid,
            'label': meta['label'],
            'icon': meta['icon'],
            'symbol': meta['symbol'],
        })
    return methods


def now_iso():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + 'Z'


def compute_expires_at(ttl_hours: int, order_override: str = None):
    if order_override:
        return order_override
    exp = datetime.datetime.utcnow() + datetime.timedelta(hours=int(ttl_hours))
    return exp.replace(microsecond=0).isoformat() + 'Z'


def sanitize_intent_for_client(intent):
    asset = intent.get('asset')
    meta = ASSETS.get(asset, {})
    return {
        'intentId': intent.get('intentId'),
        'orderId': intent.get('orderId'),
        'asset': asset,
        'assetLabel': meta.get('label', asset),
        'assetSymbol': meta.get('symbol', ''),
        'depositAddress': intent.get('depositAddress'),
        'expectedAmount': intent.get('expectedAmount'),
        'expectedAtomic': intent.get('expectedAtomic'),
        'status': intent.get('status'),
        'txHash': intent.get('txHash'),
        'confirmations': intent.get('confirmations', 0),
        'expiresAt': intent.get('expiresAt'),
        'createdAt': intent.get('createdAt'),
        'confirmedAt': intent.get('confirmedAt'),
        'exchangeRate': from_dynamo_number(intent.get('exchangeRate')),
        'baseTotalUsd': from_dynamo_number(intent.get('baseTotalUsd')),
    }
