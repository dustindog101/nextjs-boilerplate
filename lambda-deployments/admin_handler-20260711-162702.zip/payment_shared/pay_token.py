"""HMAC pay tokens for guest / white-label crypto invoice access (mirrors Next.js lib/payToken.ts)."""

import base64
import hashlib
import hmac
import json
import os
import time

TOKEN_TYP = 'pay'


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b'=').decode('ascii')


def _b64url_decode(data: str) -> bytes:
    pad = '=' * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + pad)


def verify_pay_token(token: str, expected_order_id: str) -> bool:
    """Return True when token is valid, unexpired, and bound to expected_order_id."""
    secret = os.environ.get('PAY_TOKEN_SECRET', '')
    if not secret or not token or not expected_order_id:
        return False
    try:
        dot = token.index('.')
        if dot <= 0:
            return False
        payload_b64 = token[:dot]
        sig = token[dot + 1 :]
        expected_sig = hmac.new(
            secret.encode('utf-8'),
            payload_b64.encode('utf-8'),
            hashlib.sha256,
        ).digest()
        expected_sig_b64 = _b64url_encode(expected_sig)
        if not hmac.compare_digest(sig.encode('utf-8'), expected_sig_b64.encode('utf-8')):
            return False
        payload = json.loads(_b64url_decode(payload_b64).decode('utf-8'))
        if payload.get('typ') != TOKEN_TYP:
            return False
        if payload.get('orderId') != expected_order_id:
            return False
        exp = payload.get('exp')
        if not isinstance(exp, (int, float)):
            return False
        if int(exp) < int(time.time()):
            return False
        return True
    except (ValueError, json.JSONDecodeError, UnicodeDecodeError):
        return False
